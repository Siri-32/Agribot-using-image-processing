import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the trained CNN model
model = load_model('best_model.h5')  # Replace with your model file

# Open a connection to the Raspberry Pi camera
cap = cv2.VideoCapture(0)

while True:
    # Capture a frame from the camera
    ret, frame = cap.read()

    # Preprocess the frame (resize to 139x139, normalization, etc.)
    resized_frame = cv2.resize(frame, (512, 512))
    resized_frame = resized_frame / 255.0  # Normalize to [0, 1]

    # Make predictions using the CNN model
    input_array = np.expand_dims(resized_frame, axis=0)
    predictions = model.predict(input_array)
    print(predictions)

    # Make predictions using the CNN model
    input_array = np.expand_dims(resized_frame, axis=0)
    predictions = model.predict(input_array)
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    font_thickness = 2
    font_color = (128, 0, 0)

    # Get the size of the text to be displayed

    if predictions[0][0] > predictions[0][1]:
        text_size = cv2.getTextSize("NOT A WEED", font, font_scale, font_thickness)[0]
        text_x = resized_frame.shape[1] - text_size[0] - 10  # Adjust the position as needed
        text_y = 30  # Adjust the position as needed
        # Put the text on the image
        image1 = cv2.putText(resized_frame, "NOT A WEED", (text_x, text_y), font, font_scale, font_color,
                             font_thickness)
    else:
        text_size = cv2.getTextSize("WEED", font, font_scale, font_thickness)[0]
        text_x = resized_frame.shape[1] - text_size[0] - 10  # Adjust the position as needed
        text_y = 30  # Adjust the position as needed
        # Put the text on the image
        image1 = cv2.putText(resized_frame, "WEED", (text_x, text_y), font, font_scale, font_color, font_thickness)

    # Post-process and display the results
    # Replace this with your specific post-processing and visualization code

    # Display the frame
    cv2.imshow('Video', image1)

    # Break the loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close the OpenCV window
cap.release()
cv2.destroyAllWindows()