import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the trained CNN model
model = load_model('mymodel (1).h5')  # Replace with your model file

# Open a connection to the Raspberry Pi camera
cap = cv2.VideoCapture(0)

while True:
    # Capture a frame from the camera
    ret, frame = cap.read()

    # Preprocess the frame (resize to 139x139, normalization, etc.)
    resized_frame = cv2.resize(frame, (512, 512))
    resized_frame = resized_frame / 255.0  # Normalize to [0, 1]

    # Make predictions using the CNN model
    input_array = np.expand_dims(resized_frame, axis=0)
    predictions = model.predict(input_array)

    # Post-process and display the results
    # Replace this with your specific post-processing and visualization code

    # Display the frame
    cv2.imshow('Video', frame)

    # Break the loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close the OpenCV window
cap.release()
cv2.destroyAllWindows()